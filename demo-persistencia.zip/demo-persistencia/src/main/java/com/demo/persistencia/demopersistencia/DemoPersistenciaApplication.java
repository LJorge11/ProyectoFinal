package com.demo.persistencia.demopersistencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPersistenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPersistenciaApplication.class, args);
	}

}
