package com.demo.persistencia.demopersistencia.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "especialidad")
public class Especialidad {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo_especialidad")
    private long codigoEspecialidad;
    
    @Column(name = "nombre_especialidad")
    private String nombreEspecialidad;
    
    @Column(name = "descripcion_especialidad")
    private String descripcionEspecialidad;

    // Constructor, getters y setters
}




