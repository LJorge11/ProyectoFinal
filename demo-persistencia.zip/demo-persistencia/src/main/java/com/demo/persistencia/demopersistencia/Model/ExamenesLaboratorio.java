package com.demo.persistencia.demopersistencia.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "examenes_laboratorio")
public class ExamenesLaboratorio {
    
    @Id
    @ManyToOne
    @JoinColumn(name = "codigo_paciente")
    private Paciente paciente;
    
    @Id
    @ManyToOne
    @JoinColumn(name = "codigo_medico")
    private Medico medico;
    
    @Id
    @Column(name = "fecha_examen")
    private Date fechaExamen;
    
    @Column(name = "resultados_examen")
    private String resultadosExamen;

    // Constructor, getters y setters
}
