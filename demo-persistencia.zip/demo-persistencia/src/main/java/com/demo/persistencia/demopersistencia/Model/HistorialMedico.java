package com.demo.persistencia.demopersistencia.Model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "historial_medico")
public class HistorialMedico {
    
    @Id
    @ManyToOne
    @JoinColumn(name = "codigo_paciente")
    private Paciente paciente;
    
    @Id
    @ManyToOne
    @JoinColumn(name = "codigo_medico")
    private Medico medico;
    
    @Id
    @Column(name = "fecha_consulta")
    private Date fechaConsulta;

    // Constructor, getters y setters
}

