package com.demo.persistencia.demopersistencia.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.demo.persistencia.demopersistencia.Model.Especialidad;
import com.demo.persistencia.demopersistencia.dto.EspecialidadDto;
import com.demo.persistencia.demopersistencia.services.EspecialidadServicio;

@RestController
@RequestMapping("/api/especialidad")
public class EspecialidadController {

    @Autowired
    private EspecialidadServicio especialidadServicio;
    
@GetMapping("/listarEspecialidad")
public List<Especialidad> listaDeEspecialidad(){
    return especialidadServicio.listaDeEspecialidad();
}

@PostMapping("/agregarEspecialidad")
public Especialidad agregarEspecialidad(@RequestBody EspecialidadDto especialidadJso){
    Especialidad especialidad = new Especialidad();

    especialidad.setNombreEspecialidad(especialidadJso.getNombreEspecialidad());
    especialidad.setDescripcionEspecialidad(especialidadJso.getDescripcionEspecialidad());
    return especialidadServicio.agregarESpecialidad(especialidad);

}

@GetMapping("/especialidad/{codigoEspecialidad}")
public ResponseEntity<?>buscarPorId(@PathVariable Long codigoEspecialidad, Map<String, Object> map){
    Especialidad especialidad = null;
    Map<String, Object> response = new HashMap<>();
    try {
        especialidad = especialidadServicio.findById(codigoEspecialidad);
    } catch (DataAccessException e) {
        response.put("mensaje", "Error en consulta de Especialidad");
        response.put("mensaje", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
        return new ResponseEntity<Map<String, Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
    
    }
    if (especialidad == null) {
        map.put("mensaje", "Especialidad ID".concat(codigoEspecialidad.toString().concat("No existe la Especialidad")));
        return new ResponseEntity<Map<String, Object>>(response, HttpStatus.NOT_FOUND);
        
    }
    return new ResponseEntity<Especialidad>(especialidad, HttpStatus.OK);
}

@PostMapping("/guadarE")
@ResponseStatus(HttpStatus.CREATED)
public Especialidad guardarEspecialidad(@RequestBody Especialidad especialidad){
    return especialidadServicio.save(especialidad);
}

@PutMapping("/especialidad/codigoEspecialidad")
@ResponseStatus(HttpStatus.CREATED)
public Especialidad actualizarlEspecialidad(@RequestBody Especialidad especialidad, @PathVariable Long codigoEspecialidad){
    Especialidad especialidadActualizada =especialidadServicio.findById(codigoEspecialidad);
    especialidadActualizada.setNombreEspecialidad(especialidad.getNombreEspecialidad());
    especialidadActualizada.setDescripcionEspecialidad(especialidad.getDescripcionEspecialidad());
    return especialidadServicio.save(especialidadActualizada);

}

@DeleteMapping("/especialidad({codigoEspecialidad})")
@ResponseStatus(HttpStatus.CREATED)
public void eliminarEspecialidad(@PathVariable Long codigoEspecialidad){
    especialidadServicio.delete(codigoEspecialidad);
}

}
