package com.demo.persistencia.demopersistencia.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.demo.persistencia.demopersistencia.Model.Especialidad;
import com.demo.persistencia.demopersistencia.Model.Medico;
import com.demo.persistencia.demopersistencia.Model.Paciente;
import com.demo.persistencia.demopersistencia.dto.MedicoDto;
import com.demo.persistencia.demopersistencia.services.EspecialidadServicio;
import com.demo.persistencia.demopersistencia.services.MedicoServicio;

@RestController
@RequestMapping("api/medico")

public class MedicoController {

    @Autowired
    private MedicoServicio medicoServicio;

    @Autowired
    private EspecialidadServicio especialidadServicio;

    @GetMapping("/listarMedicos")
    public List<Medico> consultarMedicos(){
        return medicoServicio.listaDeMedico();
    }

    @PostMapping("/registrarMedico")
    public ResponseEntity<Medico> crearMedico(@RequestBody MedicoDto medicoJson){
        Optional<Especialidad> especialidadOptional = Optional.empty();
        if (!especialidadOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);

        }
        Medico medico = new Medico();
        medico.setNombre(medicoJson.getNombre());
        medico.setEspecialidad(especialidadOptional.get());
        medico.setTelefono(medicoJson.getTelefono());

        Medico medicoGuardado = medicoServicio.agregarMedico(medico);
        return ResponseEntity.status(HttpStatus.CREATED).body(medicoGuardado);
    }
    
    @PostMapping("/guardarM")
    @ResponseStatus(HttpStatus.CREATED)
    public Medico guardarMedico(@RequestBody Medico medico){
        return medicoServicio.save(medico);
    }

    @GetMapping("/medico/{codigoMedico}")
public ResponseEntity<?>buscarPorId(@PathVariable Long codigoMedico, Map<String, Object> map){
    Medico medico = null;
    Map<String, Object> response = new HashMap<>();
    try {
        medico = medicoServicio.findById(codigoMedico);
    } catch (DataAccessException e) {
        response.put("mensaje", "Error en consulta del Medico");
        response.put("mensaje", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
        return new ResponseEntity<Map<String, Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
    
    }
    if (medico == null) {
        map.put("mensaje", "Medico ID".concat(codigoMedico.toString().concat("No existe el medico")));
        return new ResponseEntity<Map<String, Object>>(response, HttpStatus.NOT_FOUND);
        
    }
    return new ResponseEntity<Medico>(medico, HttpStatus.OK);
}

@PostMapping("/medico/{codigoMedico}")
@ResponseStatus(HttpStatus.CREATED)
public ResponseEntity<Medico> actualizarMedico(@PathVariable("codigoMedico") Long codigoMedico, @RequestBody MedicoDto medicoDto){
    Optional <Medico> medicoOptional = Optional.ofNullable(medicoServicio.findById(codigoMedico));
    if (medicoOptional.isPresent()) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);

        
    }
    Optional<Especialidad> especialidadOptional = especialidadServicio.buscarPorId(medicoDto.getCodigoEspecialidad());
    if (!especialidadOptional.isPresent()) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);

    }
    Medico medico = medicoOptional.get();
    medico.setNombre(medicoDto.getNombre());
    medico.setEspecialidad(especialidadOptional.get());
    medico.setTelefono(medicoDto.getTelefono());

    Medico medicoActualizado = medicoServicio.agregarMedico(medico);

    return ResponseEntity.status(HttpStatus.OK).body(medicoActualizado);
}

@DeleteMapping("/medico/{codigoMedico}")
@ResponseStatus(HttpStatus.CREATED)
public void eliminarDoctor(@PathVariable Long codigoMedico){
    medicoServicio.delete(codigoMedico);
}    
}
