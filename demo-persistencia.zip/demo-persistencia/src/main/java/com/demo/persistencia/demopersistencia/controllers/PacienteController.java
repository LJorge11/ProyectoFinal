package com.demo.persistencia.demopersistencia.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.demo.persistencia.demopersistencia.Model.Paciente;
import com.demo.persistencia.demopersistencia.dto.PacienteDto;
import com.demo.persistencia.demopersistencia.services.PacienteServicio;

@RestController
@RequestMapping("/api")
public class PacienteController {

@Autowired
private PacienteServicio pacienteServicio;

@GetMapping("/listarPaciente")
public List<Paciente> listaDePacientes(){
    return pacienteServicio.listaDePacientes();
}

@PostMapping("/registrarPaciente")
public Paciente agregarPaciente(@RequestBody PacienteDto pacienteJson){
    Paciente paciente = new Paciente();

    paciente.setNombre(pacienteJson.getNombre());
    paciente.setDireccion(pacienteJson.getDireccion());
    paciente.setFechaNacimiento(pacienteJson.getFechaNacimiento());
    return pacienteServicio.agregarPaciente(paciente);

}

@GetMapping("/paciente/{codigoPaciente}")
public ResponseEntity<?>buscarPorId(@PathVariable Long codigoPaciente, Map<String, Object> map){
    Paciente paciente = null;
    Map<String, Object> response = new HashMap<>();
    try {
        paciente = pacienteServicio.findById(codigoPaciente);
    } catch (DataAccessException e) {
        response.put("mensaje", "Error en consulta de paciente");
        response.put("mensaje", e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
        return new ResponseEntity<Map<String, Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
    
    }
    if (paciente == null) {
        map.put("mensaje", "Paciente ID".concat(codigoPaciente.toString().concat("No existe el paciente")));
        return new ResponseEntity<Map<String, Object>>(response, HttpStatus.NOT_FOUND);
        
    }
    return new ResponseEntity<Paciente>(paciente, HttpStatus.OK);
}

@PostMapping("/guardarP")
@ResponseStatus(HttpStatus.CREATED)
public Paciente save(@RequestBody Paciente paciente){
    return pacienteServicio.save(paciente);
}

@PutMapping("/paciente/{id}")
@ResponseStatus(HttpStatus.CREATED)
public Paciente actualizarPaciente(@RequestBody Paciente paciente, @PathVariable Long codigoPaciente){
    Paciente pacienteActualizado = pacienteServicio.findById(codigoPaciente);

    pacienteActualizado.setNombre(paciente.getNombre());
    pacienteActualizado.setDireccion(paciente.getDireccion());
    pacienteActualizado.setFechaNacimiento(paciente.getFechaNacimiento());
     return pacienteServicio.save(pacienteActualizado);
}

@DeleteMapping("/paciente/{id}")
@ResponseStatus(HttpStatus.NO_CONTENT)
public void eliminarPaciente(@PathVariable Long codigoPaciente){
    pacienteServicio.delete(codigoPaciente);
}
}
