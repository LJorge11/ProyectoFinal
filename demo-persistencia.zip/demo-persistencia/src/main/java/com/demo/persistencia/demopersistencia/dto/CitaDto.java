package com.demo.persistencia.demopersistencia.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.Date;

@Data
@AllArgsConstructor
public class CitaDto {

    private Date fechaCita;
    private String horaCita;
    private PacienteDto paciente;
    private MedicoDto medico;
}
