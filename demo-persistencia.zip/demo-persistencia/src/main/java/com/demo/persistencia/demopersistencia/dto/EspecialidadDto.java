package com.demo.persistencia.demopersistencia.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EspecialidadDto {
    
    private long codigoEspecialidad;
    private String nombreEspecialidad;
    private String descripcionEspecialidad;
}
