package com.demo.persistencia.demopersistencia.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.Date;

@Data
@AllArgsConstructor
public class ExamenesLaboratorioDto {

    private PacienteDto paciente;
    private MedicoDto medico;
    private Date fechaExamen;
    private String resultadosExamen;
}
