package com.demo.persistencia.demopersistencia.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.Date;

@Data
@AllArgsConstructor
public class HistorialMedicoDto {

    private PacienteDto paciente;
    private MedicoDto medico;
    private Date fechaConsulta;
}
