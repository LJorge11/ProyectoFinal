package com.demo.persistencia.demopersistencia.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MedicoDto {

    private String nombre;
    private Long codigoEspecialidad;
    private String especialidad;
    private String telefono;
}
