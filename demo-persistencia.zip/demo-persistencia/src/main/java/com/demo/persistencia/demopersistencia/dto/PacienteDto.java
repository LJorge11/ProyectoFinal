package com.demo.persistencia.demopersistencia.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;
import java.util.Date;

@Data
@AllArgsConstructor
public class PacienteDto {
    
    private String nombre;
    private String direccion;
    private Date fechaNacimiento;
    private List<CitaDto> citas;
}
