package com.demo.persistencia.demopersistencia.repositorio;

import org.springframework.data.repository.CrudRepository;
import com.demo.persistencia.demopersistencia.Model.Cita;

public interface CitaRepositorio extends CrudRepository<Cita, Long>{
}

