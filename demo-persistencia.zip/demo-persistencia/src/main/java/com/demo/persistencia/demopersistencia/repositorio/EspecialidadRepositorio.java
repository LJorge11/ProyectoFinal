package com.demo.persistencia.demopersistencia.repositorio;

import org.springframework.data.repository.CrudRepository;
import com.demo.persistencia.demopersistencia.Model.Especialidad;

public interface EspecialidadRepositorio extends CrudRepository<Especialidad, Long> {

}
