package com.demo.persistencia.demopersistencia.repositorio;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.demo.persistencia.demopersistencia.Model.ExamenesLaboratorio;

public interface ExamenesLaboratorioRepositorio extends CrudRepository<ExamenesLaboratorio, Long> {

    List<ExamenesLaboratorio> findByPacienteCodigoPaciente(int codigoPaciente);

}
