package com.demo.persistencia.demopersistencia.repositorio;

import java.util.Date;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.demo.persistencia.demopersistencia.Model.HistorialMedico;

public interface HistorialMedicoRepositorio extends CrudRepository<HistorialMedico, Long> {

    List<HistorialMedico> findByPacienteCodigoPaciente(int codigoPaciente);

    List<HistorialMedico> findByMedicoCodigoMedico(int codigoMedico);

    List<HistorialMedico> findByFechaConsulta(Date fechaConsulta);

}
