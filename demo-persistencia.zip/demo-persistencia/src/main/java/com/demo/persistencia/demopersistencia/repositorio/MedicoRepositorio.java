package com.demo.persistencia.demopersistencia.repositorio;

import org.springframework.data.repository.CrudRepository;
import com.demo.persistencia.demopersistencia.Model.Medico;

public interface MedicoRepositorio extends CrudRepository<Medico, Long> {

}
