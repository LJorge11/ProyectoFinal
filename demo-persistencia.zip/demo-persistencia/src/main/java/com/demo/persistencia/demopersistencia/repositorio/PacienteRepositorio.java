package com.demo.persistencia.demopersistencia.repositorio;

import org.springframework.data.repository.CrudRepository;
import com.demo.persistencia.demopersistencia.Model.Paciente;

public interface PacienteRepositorio extends CrudRepository<Paciente, Long> {

}
