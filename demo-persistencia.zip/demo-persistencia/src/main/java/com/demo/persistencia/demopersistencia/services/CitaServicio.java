package com.demo.persistencia.demopersistencia.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.persistencia.demopersistencia.Model.Cita;
import com.demo.persistencia.demopersistencia.repositorio.CitaRepositorio;

@Service
public class CitaServicio {
    
    @Autowired
    private CitaRepositorio citaRepositorio;

    // Agrega una nueva cita al sistema
public Cita agregarCita(Cita cita) {
    return citaRepositorio.save(cita);
}

// Cancela una cita existente por su código de cita
public void cancelarCita(int codigoCita) {
    citaRepositorio.deleteById((long) codigoCita);
}

// Modifica una cita existente
public Cita modificarCita(Cita cita) {
    return citaRepositorio.save(cita);
}

// Busca una cita por su código de cita
public Cita buscarCita(int codigoCita) {
    return citaRepositorio.findById((long) codigoCita).orElse(null);
}

// Imprime los detalles de una cita por su código de cita
public Cita imprimirCitaPorId(int codigoCita) {
    return citaRepositorio.findById((long) codigoCita).orElse(null);
}

}
