package com.demo.persistencia.demopersistencia.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.persistencia.demopersistencia.Model.Especialidad;
import com.demo.persistencia.demopersistencia.repositorio.EspecialidadRepositorio;

import jakarta.transaction.Transactional;

@Service
public class EspecialidadServicio {

    @Autowired
    private EspecialidadRepositorio especialidadRepositorio;

    // Agrega una nueva especialidad al sistema
public Especialidad agregarESpecialidad(Especialidad especialidad) {
    return especialidadRepositorio.save(especialidad);
}

// Lista todos los pacientes
public List<Especialidad> listaDeEspecialidad() {
    return (List<Especialidad>) especialidadRepositorio.findAll();
}

// Busca un paciente por su ID (código de paciente)
public Especialidad buscarEspecialidad(int codigoEspecialidad) {
    return especialidadRepositorio.findById((long) codigoEspecialidad).orElse(null);
}

public Optional<Especialidad> buscarPorId(Long codigoEspecialidad){
    return especialidadRepositorio.findById(codigoEspecialidad);
}

@Transactional
public Especialidad findById(long codigoEspecialidad){
    return especialidadRepositorio.findById(codigoEspecialidad).orElse(null);
}

@Transactional
public Especialidad save(Especialidad especialidad){
    return especialidadRepositorio.save(especialidad);
}

@Transactional
public void delete(long codigoEspecialidad){
    especialidadRepositorio.deleteById(codigoEspecialidad);
}

    
}
