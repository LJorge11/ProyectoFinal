package com.demo.persistencia.demopersistencia.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.persistencia.demopersistencia.Model.ExamenesLaboratorio;
import com.demo.persistencia.demopersistencia.repositorio.ExamenesLaboratorioRepositorio;

import java.util.List;

@Service
public class ExamenesLaboratorioServicio {

    @Autowired
    private ExamenesLaboratorioRepositorio examenesLaboratorioRepositorio;

    public List<ExamenesLaboratorio> buscarPorPaciente(int codigoPaciente) {
        return examenesLaboratorioRepositorio.findByPacienteCodigoPaciente(codigoPaciente);
    }

   
}
