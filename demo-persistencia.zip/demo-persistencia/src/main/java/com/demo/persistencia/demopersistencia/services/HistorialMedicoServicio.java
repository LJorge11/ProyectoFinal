package com.demo.persistencia.demopersistencia.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.persistencia.demopersistencia.Model.HistorialMedico;
import com.demo.persistencia.demopersistencia.repositorio.HistorialMedicoRepositorio;

import java.util.Date;
import java.util.List;

@Service
public class HistorialMedicoServicio {

    @Autowired
    private HistorialMedicoRepositorio historialMedicoRepositorio;

    // Busca el historial médico por el código de paciente y muestra el nombre del paciente, médico y la fecha de consulta
    public List<HistorialMedico> buscarPorPaciente(int codigoPaciente) {
        List<HistorialMedico> historiales = historialMedicoRepositorio.findByPacienteCodigoPaciente(codigoPaciente);
        for (HistorialMedico historial : historiales) {
            String nombrePaciente = historial.getPaciente().getNombre();
            String nombreMedico = historial.getMedico().getNombre();
            Date fechaConsulta = historial.getFechaConsulta();
            System.out.println("Nombre del paciente: " + nombrePaciente);
            System.out.println("Nombre del médico: " + nombreMedico);
            System.out.println("Fecha de consulta: " + fechaConsulta);
        }
        return historiales;
    }

    // Busca el historial médico por el código de médico y muestra el nombre del paciente, médico y la fecha de consulta
    public List<HistorialMedico> buscarPorMedico(int codigoMedico) {
        List<HistorialMedico> historiales = historialMedicoRepositorio.findByMedicoCodigoMedico(codigoMedico);
        for (HistorialMedico historial : historiales) {
            String nombrePaciente = historial.getPaciente().getNombre();
            String nombreMedico = historial.getMedico().getNombre();
            Date fechaConsulta = historial.getFechaConsulta();
            System.out.println("Nombre del paciente: " + nombrePaciente);
            System.out.println("Nombre del médico: " + nombreMedico);
            System.out.println("Fecha de consulta: " + fechaConsulta);
        }
        return historiales;
    }

    // Busca el historial médico por la fecha de consulta y muestra el nombre del paciente, médico y la fecha de consulta
    
    // Busca el historial médico por la fecha de consulta y muestra el nombre del paciente, médico y la fecha de consulta
public List<HistorialMedico> buscarPorFecha(Date fechaConsulta) {
    List<HistorialMedico> historiales = historialMedicoRepositorio.findByFechaConsulta(fechaConsulta);
    for (HistorialMedico historial : historiales) {
        String nombrePaciente = historial.getPaciente().getNombre();
        String nombreMedico = historial.getMedico().getNombre();
        Date fecha = historial.getFechaConsulta(); // Cambio de nombre aquí
        System.out.println("Nombre del paciente: " + nombrePaciente);
        System.out.println("Nombre del médico: " + nombreMedico);
        System.out.println("Fecha de consulta: " + fecha);
    }
    return historiales;
}

}
