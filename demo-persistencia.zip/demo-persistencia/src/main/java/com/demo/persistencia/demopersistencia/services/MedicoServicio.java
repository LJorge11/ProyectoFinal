package com.demo.persistencia.demopersistencia.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.persistencia.demopersistencia.Model.Medico;
import com.demo.persistencia.demopersistencia.repositorio.MedicoRepositorio;

import jakarta.transaction.Transactional;

import java.util.List;

@Service
public class MedicoServicio {

    @Autowired
    private MedicoRepositorio medicoRepositorio;

    // Agrega un nuevo médico al sistema
public Medico agregarMedico(Medico medico) {
    return medicoRepositorio.save(medico);
}

// Lista todos los pacientes
public List<Medico> listaDeMedico() {
    return (List<Medico>) medicoRepositorio.findAll();
}

// Busca un paciente por su ID (código de paciente)
public Medico buscarMedico(int codigoMedico) {
    return medicoRepositorio.findById((long) codigoMedico).orElse(null);
}


@Transactional
public Medico findById(long codigoMedico){
    return medicoRepositorio.findById(codigoMedico).orElse(null);
}

@Transactional
public Medico save(Medico medico){
    return medicoRepositorio.save(medico);
}

@Transactional
public void delete(long codigoMedico){
    medicoRepositorio.deleteById(codigoMedico);
}

}