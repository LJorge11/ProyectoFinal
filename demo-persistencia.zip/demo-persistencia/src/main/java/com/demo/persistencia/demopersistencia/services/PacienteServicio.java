package com.demo.persistencia.demopersistencia.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.persistencia.demopersistencia.Model.Paciente;
import com.demo.persistencia.demopersistencia.repositorio.PacienteRepositorio;

import jakarta.transaction.Transactional;

@Service
public class PacienteServicio {

    @Autowired
    private PacienteRepositorio pacienteRepositorio;

    // Métodos de servicio
    // Agrega un nuevo paciente al sistema
public Paciente agregarPaciente(Paciente paciente) {
    return pacienteRepositorio.save(paciente);
}

// Lista todos los pacientes
public List<Paciente> listaDePacientes() {
    return (List<Paciente>) pacienteRepositorio.findAll();
}

// Busca un paciente por su ID (código de paciente)
public Paciente buscarPaciente(int codigoPaciente) {
    return pacienteRepositorio.findById((long) codigoPaciente).orElse(null);
}


@Transactional
public Paciente findById(long codigoPaciente){
    return pacienteRepositorio.findById(codigoPaciente).orElse(null);
}

@Transactional
public Paciente save(Paciente paciente){
    return pacienteRepositorio.save(paciente);
}

@Transactional
public void delete(long codigoPaciente){
    pacienteRepositorio.deleteById(codigoPaciente);
}

}

