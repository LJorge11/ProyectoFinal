package com.demo.persistencia.demopersistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPersistenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
